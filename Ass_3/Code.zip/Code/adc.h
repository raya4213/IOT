/*
 * adc.h
 *
 *  Created on: Sep 20, 2016
 *      Author: Rahul Yamasani
 */

#ifndef ADC_H_
#define ADC_H_
#include "em_adc.h"
void adc_config();

#endif /* ADC_H_ */
