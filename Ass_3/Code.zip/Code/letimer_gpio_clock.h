/*
 * letimer_gpio_clock.h
 *
 *  Created on: Sep 20, 2016
 *      Author: Rahul Yamasani
 */

#ifndef LETIMER_GPIO_CLOCK_H_
#define LETIMER_GPIO_CLOCK_H_

void Gpio_clock_config();
void Letimer_clock();

#endif /* LETIMER_GPIO_CLOCK_H_ */
