/*
 * self_calibtarion.h
 *
 *  Created on: Sep 20, 2016
 *      Author: Rahul Yamasani
 */

#ifndef SELF_CALIBTARION_H_
#define SELF_CALIBTARION_H_

void Timer_Config();
void lfxo_selfcalib();
void ulfrxo_selfcalib();
void self_Clibration();

#endif /* SELF_CALIBTARION_H_ */
