/*
 * main.h
 *
 *  Created on: Sep 20, 2016
 *      Author: Rahul Yamasani
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "em_cmu.h"
#include "em_letimer.h"
#include "em_gpio.h"
#include "em_timer.h"

// Energy modes

#define EM0 0
#define EM1 1
#define EM2 2
#define EM3 3

// User can change the following variables
#define ENERGY_MODE 		  EM3   // defines the energy mode
#define LED0_TURNON_TIME      0.004 // Turn on time for GPIO_D Pin 6
#define LED0_DUTYCYCLE_TIME   4
#define ENABLE_SELF_CALIB           // Enables Self calibration


//When DMA_TURN_OFF is commented dma is enabled
//When DMA_TURN_OFF is uncommented dma is disabled
//#define DMA_TURN_OFF

//When ADC_POLLING is commented & dma is disabled adc data capture is done using ADC0_IRQHandler
//When ADC_POLLING is uncommented & dma is disabled adc data capture is done using polling
//#define ADC_POLLING



// Energy mode for ADC blocking
#define ADC_EM 1

// Upper and lower limits for temperature sensor
#define TEMP_UPPER_LIMIT 35
#define TEMP_LOWER_LIMIT 15

// LED 0 and 1 set and clear
#define LED0_OFF GPIO_PinOutClear(gpioPortE,2)   // Enabling the LED 0
#define LED0_ON GPIO_PinOutSet(gpioPortE,2)
#define LED1_OFF GPIO_PinOutClear(gpioPortE,3)   // Enabling the LED 0
#define LED1_ON GPIO_PinOutSet(gpioPortE,3)   // Enabling the LED 0

// Used for controlling the ambient light sensor
#define Light_Excite_Port gpioPortD
#define Light_Excite_Pin  6
#define Light_Sensor_Port gpioPortC
#define Light_Sensor_Pin  6

#define Light_Sensor_AcmpRef         acmpChannelVDD;
#define Light_Sensor_AcmpChannel     acmpChannel6;


// Setting for ADC single init typedef
#define ADC_Singleinit_Input    adcSingleInpTemp
#define ADC_Singleinit_Ref      adcRef1V25
#define ADC_Singleinit_Resol    adcRes12Bit
#define ADC_Singleinit_AcqTime  adcAcqTime1
#define ADCFreq                 130000
#define ADC_Select_HFPER_Freq   0

// Parameters for DMA Channel config
#define Dma_ChannelCfgSelect DMAREQ_ADC0_SINGLE

// Parameters for DMA destination config
#define Dma_DestCfg_dstInc  dmaDataInc2
#define Dma_DestCfg_srcInc  dmaDataIncNone
#define Dma_DestCfg_size    dmaDataSize2
#define Dma_DestCfg_arbRate dmaArbitrate1
// Used for Energy mode EM3
#if ENERGY_MODE == EM3
	#define ENABLE_EM3
#endif


#endif /* MAIN_H_ */
